/*
	Author: Kevin Ton,
	Project: First and Best Fit Memory Allocation
	Filename: main.cpp
*/

#include "memall.h"

int main(){
	//firstFit(allocate_mem(), deallocate_mem(), fragment_count());
	firstFit();
	bestFit();
	//memoryAllocation();
	//reqGeneration();
	return 0;
}
